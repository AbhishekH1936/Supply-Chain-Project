/* eslint-disable react/jsx-pascal-case */
import React from 'react';
import Navbar_GM from './Navbar_GM';


export default function ContactUs() {
  
  return (
  <>
  	<Navbar_GM/>
  </>
  );
}
