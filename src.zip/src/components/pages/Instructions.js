import React from 'react';
import Navbar from '../../components/Navbar';

export default function Instructions() {
  return (
    <>
    <Navbar/>
      <h1 className='instructions'>Instructions</h1>
    </>
  );
}
