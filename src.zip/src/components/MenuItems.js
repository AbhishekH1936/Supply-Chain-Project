export const MenuItems = [
    {
      title: 'Farmer',
      path: '/farmer',
      cName: 'dropdown-link'
    },
    {
      title: 'Agro Consultant',
      path: '/agro-consultant',
      cName: 'dropdown-link'
    },
    {
      title: 'Investor',
      path: '/investor',
      cName: 'dropdown-link'
    },
    {
      title: 'Distributor',
      path: '/distributor',
      cName: 'dropdown-link'
    },
    {
        title: 'Storage',
        path: '/storage',
        cName: 'dropdown-link'
    },
    {
        title: 'Seller',
        path: '/seller',
        cName: 'dropdown-link'
    },
    {
        title: 'Transporter',
        path: '/transporter',
        cName: 'dropdown-link'
    },
    {
        title: 'Retailer',
        path: '/retailer',
        cName: 'dropdown-link'
    }

  ];
  