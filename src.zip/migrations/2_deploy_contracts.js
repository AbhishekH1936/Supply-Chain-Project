const Scm = artifacts.require("Scm");

module.exports = function(deployer) {
  deployer.deploy(Scm);
};